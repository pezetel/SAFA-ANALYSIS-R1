'use client';

import { useState, useEffect } from 'react';
import { DashboardStats } from '@/components/DashboardStats';
import { TrendChart } from '@/components/TrendChart';
import { AircraftHeatmap } from '@/components/AircraftHeatmap';
import { ATADistribution } from '@/components/ATADistribution';
import { ProblemTypeChart } from '@/components/ProblemTypeChart';
import { TopProblems } from '@/components/TopProblems';
import { FilterPanel } from '@/components/FilterPanel';
import { DataTable } from '@/components/DataTable';
import { SAFARecord, AnalysisResult } from '@/lib/types';
import { ArrowLeft, Download, RefreshCw, AlertCircle } from 'lucide-react';
import Link from 'next/link';

export default function Dashboard() {
  const [data, setData] = useState<AnalysisResult | null>(null);
  const [filteredData, setFilteredData] = useState<SAFARecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setLoading(true);
    setError(null);
    
    try {
      // Load from localStorage
      const savedData = localStorage.getItem('safaData');
      
      if (!savedData) {
        setError('Henüz veri yüklenmedi');
        setLoading(false);
        return;
      }

      const records: SAFARecord[] = JSON.parse(savedData);
      
      // Convert date strings back to Date objects
      const parsedRecords = records.map(r => ({
        ...r,
        date: new Date(r.date)
      }));

      // Calculate statistics
      const aircraftCounts = parsedRecords.reduce((acc, record) => {
        acc[record.aircraft] = (acc[record.aircraft] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const ataCounts = parsedRecords.reduce((acc, record) => {
        acc[record.ata] = (acc[record.ata] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const problemTypeCounts = parsedRecords.reduce((acc, record) => {
        acc[record.problemType] = (acc[record.problemType] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const componentCounts = parsedRecords.reduce((acc, record) => {
        if (record.component) {
          acc[record.component] = (acc[record.component] || 0) + 1;
        }
        return acc;
      }, {} as Record<string, number>);

      // Time series data
      const timeSeriesData = parsedRecords.reduce((acc, record) => {
        const monthKey = new Date(record.date).toISOString().slice(0, 7);
        if (!acc[monthKey]) {
          acc[monthKey] = [];
        }
        acc[monthKey].push(record);
        return acc;
      }, {} as Record<string, SAFARecord[]>);

      // Top problems
      const topProblems = Object.entries(componentCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10)
        .map(([component, count]) => ({ component, count }));

      // Top aircraft
      const topAircraft = Object.entries(aircraftCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10)
        .map(([aircraft, count]) => ({ aircraft, count }));

      const result: AnalysisResult = {
        records: parsedRecords,
        statistics: {
          totalRecords: parsedRecords.length,
          uniqueAircraft: Object.keys(aircraftCounts).length,
          uniqueATA: Object.keys(ataCounts).length,
          dateRange: {
            start: new Date(Math.min(...parsedRecords.map(r => new Date(r.date).getTime()))),
            end: new Date(Math.max(...parsedRecords.map(r => new Date(r.date).getTime()))),
          },
        },
        aircraftCounts,
        ataCounts,
        problemTypeCounts,
        componentCounts,
        timeSeriesData,
        topProblems,
        topAircraft,
      };

      setData(result);
      setFilteredData(parsedRecords);
    } catch (err) {
      console.error('Error loading data:', err);
      setError('Veri yüklenirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = (filters: any) => {
    if (!data) return;

    let filtered = [...data.records];

    if (filters.dateRange) {
      const [start, end] = filters.dateRange;
      filtered = filtered.filter(r => {
        const date = new Date(r.date);
        return date >= start && date <= end;
      });
    }

    if (filters.aircraft && filters.aircraft.length > 0) {
      filtered = filtered.filter(r => filters.aircraft.includes(r.aircraft));
    }

    if (filters.ata && filters.ata.length > 0) {
      filtered = filtered.filter(r => filters.ata.includes(r.ata));
    }

    if (filters.problemType && filters.problemType.length > 0) {
      filtered = filtered.filter(r => filters.problemType.includes(r.problemType));
    }

    setFilteredData(filtered);
  };

  const exportToCSV = () => {
    if (!filteredData.length) return;

    const headers = ['W/O Number', 'Date', 'ATA', 'Aircraft', 'Problem Type', 'Component', 'Clean Description'];
    const rows = filteredData.map(r => [
      r.woNumber,
      new Date(r.date).toLocaleDateString('tr-TR'),
      r.ata,
      r.aircraft,
      r.problemType,
      r.component,
      r.cleanDescription
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `\"${cell}\"`).join(','))
    ].join('\\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `safa-analysis-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-12 w-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Veriler yüklen iyor...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">Henüz veri yüklenmedi</h2>
            <p className="text-gray-600 mb-6">
              {error || 'Dashboard\'u görüntülemek için önce bir Excel dosyası yüklemeniz gerekmektedir.'}
            </p>
            <Link 
              href="/" 
              className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              Ana sayfaya dön ve dosya yükle
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/" className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Analiz Dashboard</h1>
                <p className="text-sm text-gray-600">Toplam {data.records.length} kayıt analiz edildi</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={exportToCSV}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download className="h-4 w-4" />
                Export CSV
              </button>
              <button
                onClick={loadData}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                Yenile
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mt-4 border-b">
            <button
              onClick={() => setActiveTab('overview')}
              className={`pb-2 px-1 border-b-2 transition-colors ${
                activeTab === 'overview'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Genel Bakış
            </button>
            <button
              onClick={() => setActiveTab('trends')}
              className={`pb-2 px-1 border-b-2 transition-colors ${
                activeTab === 'trends'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Trend Analizi
            </button>
            <button
              onClick={() => setActiveTab('details')}
              className={`pb-2 px-1 border-b-2 transition-colors ${
                activeTab === 'details'
                  ? 'border-blue-600 text-blue-600 font-semibold'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Detaylı Veriler
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="mb-6">
          <FilterPanel data={data} onFilter={handleFilter} />
        </div>

        {/* Content based on active tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <DashboardStats records={filteredData} />
            
            <div className="grid lg:grid-cols-2 gap-6">
              <ATADistribution records={filteredData} />
              <ProblemTypeChart records={filteredData} />
            </div>

            <TopProblems records={filteredData} />
          </div>
        )}

        {activeTab === 'trends' && (
          <div className="space-y-6">
            <TrendChart records={filteredData} />
            <AircraftHeatmap records={filteredData} />
          </div>
        )}

        {activeTab === 'details' && (
          <DataTable records={filteredData} />
        )}
      </div>
    </div>
  );
}
